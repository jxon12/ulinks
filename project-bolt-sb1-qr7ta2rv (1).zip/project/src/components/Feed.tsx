// src/components/Feed.tsx
import React, { useMemo, useState } from "react";
import {
  ChevronLeft, Heart, Bookmark, Plus,
  Home, Compass, BookMarked, UserRound,
  MessageCircle, Calendar
} from "lucide-react";

/** ---- Props ---- */
// src/components/Feed.tsx
type FeedProps = {
  school: string;
  onBack: () => void;
  onOpenPersonal: () => void;
  onOpenProfile: () => void;
  avatar: string | null;
  signedUp?: boolean;
  onOpenPostModal?: () => void;
  onOpenAI?: () => void;
  onOpenTodo: () => void;        // ✅ 加上这行
};




type Post = { id: number; title: string; tag: string; color: string };

const POSTS: Post[] = [
  { id: 1, title: "Study calm tips", tag: "focus",  color: "from-white/10 to-white/5" },
  { id: 2, title: "Breathe 4-7-8",  tag: "breath", color: "from-white/10 to-white/5" },
  { id: 3, title: "Gentle check-in", tag: "connect",color: "from-white/10 to-white/5" },
  { id: 4, title: "Sleep winddown",  tag: "sleep",  color: "from-white/10 to-white/5" },
  { id: 5, title: "Micro-pomodoro", tag: "focus",  color: "from-white/10 to-white/5" },
  { id: 6, title: "Hydrate reminder",tag: "health", color: "from-white/10 to-white/5" },
  { id: 7, title: "Noon reset",     tag: "breath", color: "from-white/10 to-white/5" },
  { id: 8, title: "Peer circle",     tag: "connect",color: "from-white/10 to-white/5" },
];

const TAGS = ["all", "focus", "breath", "connect", "sleep", "health"];

function BubblesBg() {
  const dots = useMemo(
    () => Array.from({ length: 16 }).map((_, i) => ({
      left: `${(i * 11) % 95}%`,
      size: 4 + (i % 5),
      delay: (i * 0.7) % 8
    })),
    []
  );
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {dots.map((b, i) => (
        <span
          key={i}
          className="absolute bottom-[-10vh] rounded-full bg-white/20 backdrop-blur-sm"
          style={{
            left: b.left,
            width: `${b.size}px`,
            height: `${b.size}px`,
            animation: `bubbleUp ${12 + i}s linear ${b.delay}s infinite`,
            filter: "drop-shadow(0 0 6px rgba(255,255,255,0.25))",
          }}
        />
      ))}
    </div>
  );
}

export default function Feed({
  school,
  onBack,
  onOpenPersonal,
  onOpenProfile,
  onOpenTodo,        // ✅ 接收
  avatar,
  signedUp = true,
  onOpenPostModal,
  onOpenAI,
}: FeedProps) {
  const [liked, setLiked] = useState<Record<number, boolean>>({});
  const [saved, setSaved] = useState<Record<number, boolean>>({});
  const [active, setActive] = useState<string>("all");

  const data = POSTS.filter(p => active === "all" ? true : p.tag === active);

  const toggleLike = (id: number) => setLiked((m) => ({ ...m, [id]: !m[id] }));
  const toggleSave = (id: number) => setSaved((m) => ({ ...m, [id]: !m[id] }));

  return (
    <div className="relative min-h-screen text-white bg-gradient-to-b from-[#050b17] via-[#081226] to-[#02060c]">
      <BubblesBg />

      {/* 顶栏 */}
      <div className="sticky top-0 z-30 h-14 px-4 flex items-center justify-between backdrop-blur-md bg-black/25 border-b border-white/10">
        <button onClick={onBack} className="rounded-full px-3 py-1.5 border border-white/20 bg-white/5 active:scale-95 transition">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="tracking-[0.18em] font-semibold">ULINKS</div>
<button
  onClick={() => onOpenAI?.()}       // ✅ 调用回调
  className="rounded-full p-2 border border-white/20 bg-white/5 active:scale-95 transition"
  aria-label="AI"
>
  <MessageCircle className="w-5 h-5" />
</button>



      </div>

      {/* 欢迎语 */}
      <div className="px-4 pt-3">
        <div className="mx-auto max-w-md grid place-items-center">
          <div className="px-3 py-1.5 rounded-full text-[11px] border border-white/15 bg-white/10 backdrop-blur">
            Welcome to <span className="text-white/90">{school ?? "your campus"}</span> feed!
          </div>
        </div>
      </div>

      {/* 标签 */}
      <div className="px-4 mt-3">
        <div className="mx-auto max-w-md flex items-center justify-center gap-2 flex-wrap">
          {TAGS.map(t => (
            <button
              key={t}
              onClick={() => setActive(t)}
              className={`px-3 py-1.5 rounded-full border backdrop-blur transition
              ${active===t ? "bg-white text-black border-white" : "bg-white/10 border-white/15 text-white/85"}`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* 卡片网格 */}
      <div className="px-3 pb-28 mt-4 grid grid-cols-2 gap-3">
        {data.map((p) => (
          <div
            key={p.id}
            className={`relative rounded-2xl p-3 border border-white/12 bg-gradient-to-br ${p.color} backdrop-blur-xl hover:border-white/25 transition`}
          >
            <button
              onClick={() => toggleLike(p.id)}
              className="absolute top-2 right-2 rounded-full bg-black/35 border border-white/20 p-1 backdrop-blur active:scale-95 transition"
            >
              <Heart className={`w-4 h-4 ${liked[p.id] ? "fill-white text-white" : "text-white/70"}`} />
            </button>

            <div className="text-[10px] uppercase tracking-widest text-white/60 text-center">{p.tag}</div>
            <div className="mt-2 font-medium text-white/90 text-center">{p.title}</div>

            <div className="mt-3 flex items-center justify-between text-xs text-white/65">
              <button
                onClick={() => toggleSave(p.id)}
                className="rounded-lg px-2 py-1 border border-white/15 bg-white/5 backdrop-blur active:scale-95 transition"
                title="Save"
              >
                <Bookmark className={`inline w-4 h-4 ${saved[p.id] ? "fill-white text-white" : ""}`} />
              </button>
              <button
                onClick={onOpenPostModal}
                className="rounded-lg px-2 py-1 border border-white/15 bg-white/5 backdrop-blur active:scale-95 transition"
              >
                Open
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* 右下角 Calendar（只有已注册时显示） */}
      {signedUp && (
        <button
          onClick={onOpenPersonal}
          className="fixed right-4 bottom-40 grid place-items-center w-12 h-12 rounded-xl border border-white/20 bg-white/10 backdrop-blur shadow-lg active:scale-95 transition"
          title="Calendar"
        >
          <Calendar className="w-5 h-5" />
        </button>
      )}

      {/* 底部导航（中间大＋；倒数第二：To-Do；最右头像 -> Account） */}
      <nav className="fixed bottom-0 left-0 right-0 z-40">
        <div className="mx-auto max-w-md">
          <div className="mx-2 mb-3 rounded-3xl border border-white/10 bg-black/30 backdrop-blur-xl shadow-lg">
            <div className="h-16 grid grid-cols-5 place-items-center text-white/70">
              <button className="hover:text-white transition" aria-label="Home"><Home className="w-5 h-5" /></button>
              <button className="hover:text-white transition" aria-label="Explore"><Compass className="w-5 h-5" /></button>

              {/* 中间大＋ */}
              <div className="relative -mt-6">
                <button
                  onClick={onOpenPostModal}
                  className="grid place-items-center w-14 h-14 rounded-full border border-white/20 bg-white text-black shadow-lg active:scale-95 transition"
                  aria-label="Create"
                >
                  <Plus className="w-6 h-6" />
                </button>
              </div>

              {/* ✅ 倒数第二：To-Do */}
              {/* 倒数第二个按钮 -> To-Do */}
<button
  className="hover:text-white transition"
  aria-label="To-Do"
  onClick={onOpenTodo}                 // ✅ 新增
>
  <BookMarked className="w-5 h-5" />
</button>


              {/* 最右头像按钮：点击进入 Account */}
              <button
                onClick={onOpenProfile}
                className="flex flex-col items-center text-xs hover:text-white transition"
                aria-label="My Account"
              >
                {avatar ? (
                  <img
                    src={avatar}
                    alt="avatar"
                    className="w-6 h-6 rounded-full mb-1 object-cover border border-white/20"
                  />
                ) : (
                  <UserRound className="w-6 h-6 mb-1" />
                )}
                Me
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* 局部动画（供气泡用） */}
      <style>{`
        @keyframes bubbleUp {
          0%   { transform: translateY(0) translateX(0) scale(0.8); opacity: 0; }
          15%  { opacity: .6; }
          100% { transform: translateY(-110vh) translateX(20px) scale(1.05); opacity: 0; }
        }
      `}</style>
    </div>
  );
}
