// src/components/ChatPhone.tsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  X, Mic, Image as Img, Send, Plus, ChevronLeft, Search, User,
  MessageCircle, Users, Compass, Settings, Sun, Moon, Star
} from "lucide-react";

/* ---------- Props ---------- */
type Props = {
  open: boolean;
  onClose: () => void;
};

/* ---------- Types & Data ---------- */
type Mood = "sunny" | "cloudy" | "storm";
type Tab = "chats" | "contacts" | "discover" | "me";
type Screen = "lock" | "home" | "uchat" | "chat";

type BotId = "skylar" | "louise" | "luther" | "seahorse";
type Msg = { id: number; role: "bot" | "me"; text: string; bot?: BotId };

const BOTS: Record<BotId, { name: string; title: string; color: string; emoji: string }> = {
  skylar:  { name: "Skylar",  title: "小飞象", emoji: "🐘", color: "#7dd3fc" }, // 外向 创意
  louise:  { name: "Louise",  title: "水母",   emoji: "🪼", color: "#c7d2fe" }, // 外向 温柔
  luther:  { name: "Luther",  title: "鲸",     emoji: "🐋", color: "#93c5fd" }, // 内向 supportive
  seahorse:{ name: "Rei",     title: "海马",   emoji: "🦄", color: "#a5b4fc" }, // 冷感 搞笑
};

const APP_ICONS = [
  { key: "uchat", label: "UChat", icon: <MessageCircle className="w-5 h-5" /> },
  { key: "divination", label: "占卜", icon: <Star className="w-5 h-5" /> },
  { key: "games", label: "游戏", icon: <Compass className="w-5 h-5" /> },
  { key: "mood", label: "情绪天气", icon: <Sun className="w-5 h-5" /> },
];

/* ---------- Helpers ---------- */
function moodBg(mood: Mood) {
  switch (mood) {
    case "sunny":
      return "linear-gradient(180deg,#eaf3ff 0%, #f7fbff 40%, #e8f0ff 100%)";
    case "cloudy":
      return "linear-gradient(180deg,#dfe7f5 0%, #e6ecf7 40%, #d7deef 100%)";
    case "storm":
      return "linear-gradient(180deg,#0d1422 0%, #141c2b 40%, #0b1322 100%)";
  }
}
function moodSky(mood: Mood) {
  if (mood === "storm") return "bg-[radial-gradient(circle_at_50%_20%,rgba(50,80,140,.25),transparent_60%)]";
  if (mood === "cloudy") return "bg-[radial-gradient(circle_at_50%_20%,rgba(120,160,210,.25),transparent_60%)]";
  return "bg-[radial-gradient(circle_at_50%_20%,rgba(140,200,255,.28),transparent_60%)]";
}

/* =======================================================
   ChatPhone  ——  所有 early return 放到 Hook 之前，保证 Hook 顺序稳定
======================================================= */
export default function ChatPhone({ open, onClose }: Props) {
  if (!open) return null; // ✅ 提前 return，避免 Hook 顺序问题

  /* ---------- Stable Hooks (顺序不可变) ---------- */
  // 顶层状态
  const [screen, setScreen] = useState<Screen>("lock");
  const [tab, setTab] = useState<Tab>("chats");
  const [mood, setMood] = useState<Mood>("sunny");

  // 锁屏/时间
  const [now, setNow] = useState<Date>(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30_000);
    return () => clearInterval(t);
  }, []);
  const timeText = useMemo(() => {
    const h = now.getHours().toString().padStart(2, "0");
    const m = now.getMinutes().toString().padStart(2, "0");
    const weekday = ["日","一","二","三","四","五","六"][now.getDay()];
    const mon = (now.getMonth()+1).toString().padStart(2,"0");
    const day = now.getDate().toString().padStart(2,"0");
    return { hm: `${h}:${m}`, md: `${mon}月${day}日  星期${weekday}` };
  }, [now]);

  // 聊天
  const [activeBot, setActiveBot] = useState<BotId | null>(null);
  const [messages, setMessages] = useState<Msg[]>([
    { id: 1, role: "bot", text: "Hi～我是小海鹅。今天心情怎么样？", bot: "louise" },
  ]);
  const [input, setInput] = useState("");
  const chatBodyRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    setTimeout(() => chatBodyRef.current?.scrollTo({ top: 999999 }), 0);
  }, [messages.length, screen]);

  // 我的（UChat 内部资料，与外部 Account 分离）
  const [myNick, setMyNick] = useState("我");
  const [myAvatar, setMyAvatar] = useState<string | null>(null);

  // “心声/记忆” 抽屉
  const [drawerOpen, setDrawerOpen] = useState<"off" | "hearts" | "memory">("off");

  /* ---------- 交互 ---------- */
  const openUChat = () => { setScreen("uchat"); setTab("chats"); };
  const send = () => {
    const text = input.trim();
    if (!text) return;
    const bot = activeBot ?? "louise";
    setMessages((m) => [...m, { id: Date.now(), role: "me", text }]);
    setInput("");
    // demo 回复
    setTimeout(() => {
      const reply =
        bot === "skylar"  ? "我有个灵感💡！要不要试试把这件事做成一个微挑战？"
      : bot === "luther"  ? "我听着呢。慢慢说，不用急。你已经做得很好了。"
      : bot === "seahorse"? "表面高冷，其实在偷偷给你鼓掌👏（别告诉别人）"
      : "我懂你～要不要做个 3 分钟呼吸？我陪你。";
      setMessages((m) => [
        ...m,
        { id: Date.now() + 1, role: "bot", text: reply, bot }
      ]);
    }, 500);
  };

  /* ---------- 机身外壳 ---------- */
  const outer = (
    <div
      className="absolute pointer-events-auto right-4 bottom-4 sm:right-6 sm:bottom-6"
      style={{ width: "min(92vw, 420px)", aspectRatio: "1179/2556" }}
    >
      <div
        className="relative w-full h-full rounded-[42px] shadow-[0_20px_60px_rgba(0,0,0,.45)]"
        style={{
          background: "linear-gradient(180deg,#0c0f16 0%, #0b0f17 60%, #0c0f16 100%)",
          border: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        {/* 机身边框 */}
        <div className="absolute inset-[8px] rounded-[36px] bg-black/95" />
        {/* 灵动岛 */}
        <div className="absolute left-1/2 -translate-x-1/2 top-[18px] w-[110px] h-[34px] rounded-[22px] bg-black shadow-[0_2px_8px_rgba(0,0,0,.5)]" />
        {/* 屏幕 */}
        <div
          className={`absolute inset-[14px] rounded-[30px] overflow-hidden text-[#0a0f18] ${moodSky(mood)}`}
          style={{ background: moodBg(mood) }}
        >
          {/* 顶部栏 */}
          <div className="relative h-11 flex items-center justify-center bg-white/80 backdrop-blur border-b border-black/5">
            <div className="text-[13px] font-medium tracking-wide">
              {screen === "lock" ? "锁屏" : screen === "home" ? "主屏" : screen === "uchat" ? "UChat" : (activeBot ? BOTS[activeBot].name : "聊天")}
            </div>
            <button
              onClick={onClose}
              className="absolute right-2 top-1/2 -translate-y-1/2 grid place-items-center w-8 h-8 rounded-full hover:bg-black/5"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* 主体区域 */}
          {screen === "lock" && (
            <LockScreen
              time={timeText}
              mood={mood}
              onUnlock={() => setScreen("home")}
              onToggleMood={() => setMood(m => m === "sunny" ? "cloudy" : m === "cloudy" ? "storm" : "sunny")}
            />
          )}

          {screen === "home" && (
            <HomeScreen onOpenApp={(k) => (k === "uchat" ? openUChat() : alert(`占位：${k}`))} />
          )}

          {screen === "uchat" && (
            <UChat
              tab={tab}
              setTab={setTab}
              myNick={myNick}
              setMyNick={setMyNick}
              myAvatar={myAvatar}
              setMyAvatar={setMyAvatar}
              onBack={() => setScreen("home")}
              onOpenChat={(bot) => { setActiveBot(bot); setScreen("chat"); }}
            />
          )}

          {screen === "chat" && activeBot && (
            <ChatView
              bot={activeBot}
              messages={messages.filter(m => !m.bot || m.bot === activeBot)}
              input={input}
              setInput={setInput}
              onSend={send}
              onBack={() => setScreen("uchat")}
              bodyRef={chatBodyRef}
              onOpenPlus={(t) => setDrawerOpen(t)}
            />
          )}

          {/* 抽屉：心声/记忆 */}
          {drawerOpen !== "off" && (
            <Drawer onClose={()=>setDrawerOpen("off")} type={drawerOpen} />
          )}
        </div>
      </div>
    </div>
  );

  /* ---------- 遮罩 + 外壳 ---------- */
  return (
    <div className="fixed z-[80] inset-0 pointer-events-none" aria-modal="true" role="dialog">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm pointer-events-auto" onClick={onClose} />
      {outer}
    </div>
  );
}

/* =======================================================
   子组件
======================================================= */
function LockScreen({
  time, mood, onUnlock, onToggleMood,
}: { time:{hm:string;md:string}; mood:Mood; onUnlock:()=>void; onToggleMood:()=>void }) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-between">
      <div className="pt-10 text-center">
        <div className="text-xs text-black/45">{time.md}</div>
        <div className="mt-1 text-[58px] leading-none font-semibold tracking-tight">{time.hm}</div>
      </div>

      <div className="pb-16 flex flex-col items-center gap-4">
        <button
          onClick={onUnlock}
          className="px-5 py-2 rounded-full bg-white/80 border border-black/10 backdrop-blur hover:bg-white transition text-sm"
        >
          轻扫/点按解锁
        </button>
        <button
          onClick={onToggleMood}
          className="px-4 py-2 rounded-full bg-white/70 border border-black/10 text-xs hover:bg-white"
          title="情绪天气切换"
        >
          {mood === "sunny" ? <Sun className="w-4 h-4 inline" /> : mood === "cloudy" ? <Moon className="w-4 h-4 inline" /> : <Star className="w-4 h-4 inline" />} 情绪天气
        </button>
      </div>
    </div>
  );
}

function HomeScreen({ onOpenApp }: { onOpenApp: (key: string)=>void }) {
  return (
    <div className="absolute inset-0 px-6 py-5">
      <div className="grid grid-cols-4 gap-4 mt-4">
        {APP_ICONS.map(app => (
          <button
            key={app.key}
            onClick={() => onOpenApp(app.key)}
            className="h-16 rounded-2xl bg-white/70 backdrop-blur border border-black/10 flex flex-col items-center justify-center hover:bg-white"
          >
            {app.icon}
            <div className="text-[11px] mt-1 text-black/70">{app.label}</div>
          </button>
        ))}
      </div>
    </div>
  );
}

function UChat({
  tab, setTab, onBack, onOpenChat, myNick, setMyNick, myAvatar, setMyAvatar
}: {
  tab: Tab; setTab: (t:Tab)=>void; onBack:()=>void; onOpenChat:(b:BotId)=>void;
  myNick: string; setMyNick:(s:string)=>void; myAvatar: string|null; setMyAvatar:(s:string|null)=>void;
}) {
  return (
    <div className="absolute inset-0 flex flex-col">
      <div className="h-10 flex items-center gap-2 px-2">
        <button onClick={onBack} className="w-8 h-8 grid place-items-center rounded-full hover:bg-black/5">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex-1 relative">
          <input className="w-full h-8 rounded-xl bg-white/70 border border-black/10 px-7 text-[12px]" placeholder="搜索" />
          <Search className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 text-black/50" />
        </div>
        <button className="w-8 h-8 grid place-items-center rounded-full hover:bg-black/5">
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {tab === "chats" && (
          <>
            {Object.keys(BOTS).map((k) => {
              const id = k as BotId;
              const b = BOTS[id];
              return (
                <button
                  key={id}
                  onClick={() => onOpenChat(id)}
                  className="w-full text-left bg-white/80 border border-black/10 rounded-2xl px-3 py-2 flex items-center gap-3 hover:bg-white"
                >
                  <Avatar id={id} />
                  <div className="flex-1">
                    <div className="text-[13px] font-medium">{b.name} · {b.title}</div>
                    <div className="text-[11px] text-black/50">上次：嗨～还好吗？</div>
                  </div>
                </button>
              );
            })}
          </>
        )}

        {tab === "contacts" && (
          <div className="grid grid-cols-4 gap-3">
            {(Object.keys(BOTS) as BotId[]).map(id => (
              <div key={id} className="flex flex-col items-center">
                <Avatar id={id} />
                <div className="text-[11px] mt-1">{BOTS[id].name}</div>
              </div>
            ))}
          </div>
        )}

        {tab === "discover" && (
          <div className="text-[13px] text-black/60">
            发现页占位：以后可以做“海洋风朋友圈 / 小卡片”流。
          </div>
        )}

        {tab === "me" && (
          <div className="space-y-3">
            <div className="bg-white/80 border border-black/10 rounded-2xl p-3 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-black/10 grid place-items-center overflow-hidden">
                {myAvatar ? <img src={myAvatar} className="w-full h-full object-cover" /> : <User className="w-5 h-5" />}
              </div>
              <input
                value={myNick}
                onChange={(e)=>setMyNick(e.target.value)}
                className="flex-1 h-9 px-2 rounded-lg bg-white/70 border border-black/10 text-[13px]"
                placeholder="昵称"
              />
              <button
                onClick={()=>{
                  const url = prompt("输入头像图片 URL（演示）");
                  if (url === null) return;
                  setMyAvatar(url || null);
                }}
                className="px-3 h-9 rounded-lg bg-black/80 text-white text-[12px]"
              >
                更换头像
              </button>
            </div>
            <div className="text-[12px] text-black/50">
              （这里的昵称与头像仅在 UChat 内使用，不影响外部 My Account）
            </div>
          </div>
        )}
      </div>

      {/* 底部 Tab */}
      <div className="h-12 border-t border-black/10 bg-white/80 backdrop-blur grid grid-cols-4">
        <TabBtn icon={<MessageCircle className="w-4 h-4" />} text="列表" active={tab==="chats"} onClick={()=>setTab("chats")} />
        <TabBtn icon={<Users className="w-4 h-4" />} text="通讯录" active={tab==="contacts"} onClick={()=>setTab("contacts")} />
        <TabBtn icon={<Compass className="w-4 h-4" />} text="发现" active={tab==="discover"} onClick={()=>setTab("discover")} />
        <TabBtn icon={<Settings className="w-4 h-4" />} text="我的" active={tab==="me"} onClick={()=>setTab("me")} />
      </div>
    </div>
  );
}

function ChatView({
  bot, messages, input, setInput, onSend, onBack, bodyRef, onOpenPlus
}: {
  bot: BotId; messages: Msg[]; input:string; setInput:(v:string)=>void;
  onSend:()=>void; onBack:()=>void; bodyRef: React.RefObject<HTMLDivElement>;
  onOpenPlus: (t:"hearts"|"memory")=>void;
}) {
  return (
    <div className="absolute inset-0 flex flex-col">
      <div className="h-10 flex items-center gap-2 px-2">
        <button onClick={onBack} className="w-8 h-8 grid place-items-center rounded-full hover:bg-black/5">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <Avatar id={bot} />
          <div className="text-[13px] font-medium">{BOTS[bot].name} · {BOTS[bot].title}</div>
        </div>
      </div>

      <div ref={bodyRef} className="flex-1 overflow-y-auto px-3 py-3 space-y-8">
        {messages.map((m)=>(
          <div key={m.id} className={`flex ${m.role==="me" ? "justify-end" : "justify-start items-start gap-2"}`}>
            {m.role==="bot" && <Avatar id={bot} size={28} />}
            <div
              className={
                m.role==="me"
                  ? "max-w-[75%] rounded-2xl px-3.5 py-2.5 text-[14px] bg-[#4253ff] text-white shadow"
                  : "max-w-[75%] rounded-2xl px-3.5 py-2.5 text-[14px] bg-white shadow border border-black/5"
              }
            >
              {m.text}
            </div>
          </div>
        ))}
      </div>

      <div className="h-[60px] px-2 flex items-center gap-2 border-t border-black/5 bg-white/85 backdrop-blur"
           style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}>
        <button onClick={()=>onOpenPlus("hearts")} className="w-9 h-9 grid place-items-center rounded-full hover:bg-black/5">
          <Plus className="w-5 h-5" />
        </button>
        <button className="w-9 h-9 grid place-items-center rounded-full hover:bg-black/5">
          <Img className="w-5 h-5" />
        </button>
        <button className="w-9 h-9 grid place-items-center rounded-full hover:bg-black/5">
          <Mic className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <input
            value={input}
            onChange={(e)=>setInput(e.target.value)}
            onKeyDown={(e)=> e.key==="Enter" && onSend()}
            placeholder="说点什么…"
            className="w-full h-10 px-3 rounded-2xl bg-[#f3f5fb] border border-black/5 text-[14px] outline-none focus:border-black/15"
          />
        </div>
        <button onClick={onSend} className="w-9 h-9 grid place-items-center rounded-full bg-[#4253ff] text-white hover:opacity-90">
          <Send className="w-4 h-4" />
        </button>
        <button onClick={()=>onOpenPlus("memory")} className="w-9 h-9 grid place-items-center rounded-full hover:bg-black/5" title="记忆">
          <Star className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

/* ---------- 小组件 ---------- */
function Avatar({ id, size=36 }: { id: BotId; size?: number }) {
  const b = BOTS[id];
  return (
    <div
      className="rounded-full grid place-items-center border border-black/10 shadow"
      style={{ width: size, height: size, backgroundColor: b.color }}
      title={`${b.name} · ${b.title}`}
    >
      <span className="text-[14px]">{b.emoji}</span>
    </div>
  );
}
function TabBtn({ icon, text, active, onClick }: { icon: React.ReactNode; text:string; active:boolean; onClick:()=>void }) {
  return (
    <button onClick={onClick} className={`flex flex-col items-center justify-center ${active ? "text-black" : "text-black/55"}`}>
      {icon}
      <div className="text-[10px] mt-0.5">{text}</div>
    </button>
  );
}
function Drawer({ type, onClose }: { type:"hearts"|"memory"; onClose:()=>void }) {
  return (
    <div className="absolute inset-0 bg-black/10">
      <div className="absolute bottom-0 left-0 right-0 rounded-t-2xl bg-white/95 border-t border-black/10 p-4">
        <div className="flex items-center justify-between">
          <div className="text-sm font-medium">{type === "hearts" ? "小海鹅的心声" : "小海鹅的记忆"}</div>
          <button onClick={onClose} className="w-8 h-8 grid place-items-center rounded-full hover:bg-black/5">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="mt-2 text-[13px] text-black/70 leading-relaxed">
          {type === "hearts"
            ? "（占位）根据你最近的聊天语境，给出一段温柔的小心声与理解。"
            : "（占位）这里会以“他的视角”记录你的微日记，支持搜索与导出。"}
        </div>
      </div>
    </div>
  );
}
