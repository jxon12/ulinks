// src/components/ToDoList.tsx
import React, { useEffect, useMemo, useState } from "react";
import {
  PlusCircle, CheckCircle2, Clock, Bell, CalendarDays,
  Link as LinkIcon, Check, X, Timer, Play, Pause, ChevronRight
} from "lucide-react";

/** ============ 基础类型 ============ */
type Task = { id: string; title: string; done: boolean; bucket?: "IU"|"IN"|"NU"|"NN" };

/** 生成 ID */
const rid = () => (crypto?.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()));

/** ============ 组件 ============ */
export default function ToDoList() {
  /** 任务列表（简单演示版） */
  const [tasks, setTasks] = useState<Task[]>([
    { id: rid(), title: "Try adding a task", done: false, bucket: "IN" },
  ]);
  const [input, setInput] = useState("");

  /** 日历连接占位 */
  const [appleConnected, setAppleConnected]   = useState(false);
  const [googleConnected, setGoogleConnected] = useState(false);
  const [ulinksEnabled, setUlinksEnabled]     = useState(true);

  /** Pomodoro 占位 */
  const [pomoSecondsLeft, setPomoSecondsLeft] = useState(25 * 60); // 25min
  const [pomoRunning, setPomoRunning]         = useState(false);

  useEffect(() => {
    if (!pomoRunning) return;
    const t = setInterval(() => {
      setPomoSecondsLeft((s) => (s > 0 ? s - 1 : 0));
    }, 1000);
    return () => clearInterval(t);
  }, [pomoRunning]);

  const mmss = useMemo(() => {
    const m = Math.floor(pomoSecondsLeft / 60);
    const s = pomoSecondsLeft % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  }, [pomoSecondsLeft]);

  const ringDash = useMemo(() => {
    const total = 25 * 60;
    const ratio = pomoSecondsLeft / total;
    const CIRC = 2 * Math.PI * 56; // r=56
    return Math.max(0, CIRC * ratio);
  }, [pomoSecondsLeft]);

  /** 添加任务（默认放到“重要不紧急 IN”） */
  const addTask = () => {
    const title = input.trim();
    if (!title) return;
    setTasks((ts) => [{ id: rid(), title, done: false, bucket: "IN" }, ...ts]);
    setInput("");
  };

  const toggle = (id: string) =>
    setTasks((ts) => ts.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));

  /** Priority Matrix 4 桶 */
  const buckets: Record<NonNullable<Task["bucket"]>, Task[]> = {
    IU: tasks.filter(t => t.bucket === "IU"),
    IN: tasks.filter(t => t.bucket === "IN"),
    NU: tasks.filter(t => t.bucket === "NU"),
    NN: tasks.filter(t => t.bucket === "NN"),
  };

  const moveTo = (id: string, bucket: Task["bucket"]) =>
    setTasks(ts => ts.map(t => (t.id === id ? { ...t, bucket } : t)));

  /** 预设按钮：25/15/5 分钟 */
  const setPreset = (min: number) => {
    setPomoRunning(false);
    setPomoSecondsLeft(min * 60);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#050b17] via-[#081226] to-[#02060c] text-white pt-16 pb-24">
      {/* 顶部 */}
      <header className="sticky top-0 z-20 px-5 py-3 backdrop-blur bg-white/5 border-b border-white/10 flex items-center justify-between">
        <div className="font-semibold tracking-[0.14em]">TO-DO</div>
        <div className="flex items-center gap-2 text-white/70">
          <CalendarDays className="w-5 h-5" />
          <Bell className="w-5 h-5" />
        </div>
      </header>

      {/* 输入行 */}
      <div className="max-w-md mx-auto px-5 mt-5">
        <div className="flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Hey~ What do you want to do today?"
            className="flex-1 h-12 px-4 rounded-2xl bg-white/5 border border-white/15 placeholder-white/40 focus:outline-none focus:border-white/35 focus:ring-2 focus:ring-white/15"
          />
          <button
            onClick={addTask}
            className="px-4 rounded-2xl bg-white text-black font-medium hover:bg-white/90 transition"
            aria-label="Add task"
            title="Add"
          >
            <PlusCircle className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* 日历同步占位 */}
      <section className="max-w-md mx-auto px-5 mt-6">
        <h3 className="text-sm text-white/80 mb-2">Calendar Sync</h3>
        <div className="rounded-2xl border border-white/12 bg-white/5 backdrop-blur divide-y divide-white/10">
          <SyncRow
            title="Apple Calendar"
            subtitle="iCloud • read & write (placeholder)"
            connected={appleConnected}
            onToggle={() => setAppleConnected(v => !v)}
          />
          <SyncRow
            title="Google Calendar"
            subtitle="GCal • read & write (placeholder)"
            connected={googleConnected}
            onToggle={() => setGoogleConnected(v => !v)}
          />
          <SyncRow
            title="Ulinks Calendar"
            subtitle="Use in-app calendar"
            connected={ulinksEnabled}
            onToggle={() => setUlinksEnabled(v => !v)}
          />
        </div>
        <p className="mt-2 text-xs text-white/50">
          * 这只是 UI 占位。真正接入后会弹系统授权并选择要同步的日历。
        </p>
      </section>

      {/* Priority Matrix 占位 */}
      <section className="max-w-md mx-auto px-5 mt-8">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm text-white/80">Priority Matrix</h3>
          <a className="text-xs text-white/60 hover:text-white/90 inline-flex items-center gap-1" href="#!">
            Manage
            <ChevronRight className="w-4 h-4" />
          </a>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <MatrixCell
            title="Important & Urgent"
            hint="Do now"
            tasks={buckets.IU}
            onToggle={toggle}
            onAdd={() => setTasks(ts => [{ id: rid(), title: "New task", done: false, bucket: "IU" }, ...ts])}
            onMove={(id) => moveTo(id, "IN")}
          />
          <MatrixCell
            title="Important, not Urgent"
            hint="Plan"
            tasks={buckets.IN}
            onToggle={toggle}
            onAdd={() => setTasks(ts => [{ id: rid(), title: "New task", done: false, bucket: "IN" }, ...ts])}
            onMove={(id) => moveTo(id, "IU")}
          />
          <MatrixCell
            title="Not Important, Urgent"
            hint="Delegate"
            tasks={buckets.NU}
            onToggle={toggle}
            onAdd={() => setTasks(ts => [{ id: rid(), title: "New task", done: false, bucket: "NU" }, ...ts])}
            onMove={(id) => moveTo(id, "NN")}
          />
          <MatrixCell
            title="Not Important & not Urgent"
            hint="Later"
            tasks={buckets.NN}
            onToggle={toggle}
            onAdd={() => setTasks(ts => [{ id: rid(), title: "New task", done: false, bucket: "NN" }, ...ts])}
            onMove={(id) => moveTo(id, "NU")}
          />
        </div>
      </section>

      {/* Pomodoro 占位 */}
      <section className="max-w-md mx-auto px-5 mt-8">
        <h3 className="text-sm text-white/80 mb-3">Pomodoro</h3>

        <div className="rounded-2xl border border-white/12 bg-white/5 backdrop-blur p-5 flex flex-col items-center">
          <div className="relative w-40 h-40">
            {/* 背景环 */}
            <svg viewBox="0 0 128 128" className="w-40 h-40 -rotate-90">
              <circle cx="64" cy="64" r="56" fill="none" stroke="rgba(255,255,255,.15)" strokeWidth="10" />
              <circle
                cx="64" cy="64" r="56" fill="none"
                stroke="white" strokeWidth="10" strokeLinecap="round"
                strokeDasharray={`${ringDash} 9999`}
              />
            </svg>
            <div className="absolute inset-0 grid place-items-center">
              <div className="text-3xl font-semibold tracking-wide">{mmss}</div>
            </div>
          </div>

          <div className="mt-4 flex gap-2">
            {[25, 15, 5].map(min => (
              <button
                key={min}
                onClick={() => setPreset(min)}
                className="px-3 py-1.5 rounded-full border border-white/15 bg-white/5 text-sm hover:bg-white/10"
              >
                {min} min
              </button>
            ))}
          </div>

          <div className="mt-4 flex items-center gap-3">
            <button
              onClick={() => setPomoRunning(r => !r)}
              className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-white text-black font-medium hover:bg-white/90 transition"
            >
              {pomoRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              {pomoRunning ? "Pause" : "Start"}
            </button>
            <button
              onClick={() => { setPomoRunning(false); setPomoSecondsLeft(25*60); }}
              className="px-4 py-2 rounded-full border border-white/15 bg-white/5 hover:bg-white/10"
            >
              Reset
            </button>
          </div>

          <p className="mt-3 text-xs text-white/50">
            * 占位 UI。后续会支持专注音景、自动写入 Calendar、专注结束提醒等。
          </p>
        </div>
      </section>

      {/* 简单任务列表（兜底区） */}
      <section className="max-w-md mx-auto px-5 mt-8">
        <h3 className="text-sm text-white/80 mb-2">All tasks</h3>
        <ul className="space-y-2">
          {tasks.map((t) => (
            <li
              key={t.id}
              className="flex items-center justify-between rounded-2xl border border-white/12 bg-white/5 backdrop-blur px-4 py-3"
            >
              <button
                onClick={() => toggle(t.id)}
                className={`mr-3 rounded-full ${t.done ? "text-emerald-300" : "text-white/60"}`}
                aria-label="toggle"
              >
                <CheckCircle2 className="w-5 h-5" />
              </button>
              <div className={`flex-1 text-sm ${t.done ? "line-through text-white/40" : "text-white/90"}`}>
                {t.title}
              </div>
              <Clock className="w-4 h-4 text-white/40" />
            </li>
          ))}
        </ul>
      </section>

      <div className="h-10" />
    </div>
  );
}

/** ============ 子组件们 ============ */

/** 日历链接行（占位） */
function SyncRow({
  title, subtitle, connected, onToggle,
}: { title: string; subtitle: string; connected: boolean; onToggle: () => void; }) {
  return (
    <div className="flex items-center justify-between px-4 py-3">
      <div>
        <div className="text-white/90 text-sm">{title}</div>
        <div className="text-white/50 text-xs">{subtitle}</div>
      </div>
      <button
        onClick={onToggle}
        className={`inline-flex items-center gap-2 h-9 px-3 rounded-xl border ${
          connected ? "bg-white text-black border-white" : "bg-white/5 text-white border-white/15"
        } hover:opacity-90 transition`}
      >
        {connected ? <Check className="w-4 h-4" /> : <LinkIcon className="w-4 h-4" />}
        {connected ? "Connected" : "Connect"}
      </button>
    </div>
  );
}

/** Matrix 单元格（占位） */
function MatrixCell({
  title, hint, tasks, onToggle, onAdd, onMove,
}: {
  title: string;
  hint: string;
  tasks: Task[];
  onToggle: (id: string) => void;
  onAdd: () => void;
  onMove: (id: string) => void;
}) {
  return (
    <div className="rounded-xl border border-white/12 bg-white/5 backdrop-blur p-3">
      <div className="text-[11px] uppercase tracking-widest text-white/60">{title}</div>
      <div className="text-xs text-white/50 mb-2">{hint}</div>

      <button
        onClick={onAdd}
        className="mb-2 inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full border border-white/15 bg-white/5 hover:bg-white/10"
      >
        <PlusCircle className="w-3 h-3" /> Add
      </button>

      <ul className="space-y-1">
        {tasks.slice(0, 3).map(t => (
          <li
            key={t.id}
            className="flex items-center justify-between rounded-lg border border-white/10 bg-white/5 px-2 py-1.5"
          >
            <button
              onClick={() => onToggle(t.id)}
              className={`mr-2 rounded-full ${t.done ? "text-emerald-300" : "text-white/60"}`}
              aria-label="toggle"
            >
              <CheckCircle2 className="w-4 h-4" />
            </button>
            <div className={`flex-1 text-xs ${t.done ? "line-through text-white/40" : "text-white/85"}`}>
              {t.title}
            </div>
            <button
              onClick={() => onMove(t.id)}
              className="text-[10px] px-2 py-0.5 rounded-full border border-white/15 bg-white/5 hover:bg-white/10"
            >
              Move
            </button>
          </li>
        ))}
        {tasks.length > 3 && (
          <li className="text-[10px] text-white/50">+{tasks.length - 3} more…</li>
        )}
      </ul>
    </div>
  );
}
